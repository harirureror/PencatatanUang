# Catat Transaksi

Mencatat setiap uang masuk dan uang keluar lapangan agar tidak ada yang terlewat.

## Spesifikasi

### Tujuan
Mencatat setiap uang masuk dan uang keluar lapangan agar tidak ada yang terlewat dan saldo proyek selalu akurat.
### Selesai bila
- Pengguna bisa menambah catatan pengeluaran atau pemasukan dari halaman utama dalam beberapa ketukan.
- Setiap catatan tersimpan dengan jumlah, kategori, tanggal, dan keterangan (opsional).
- Catatan yang salah bisa diubah atau dihapus, dan saldo ikut menyesuaikan.
- Daftar transaksi terbaru langsung terlihat di dashboard atau halaman transaksi.

## Sub-fitur: Catat Pengeluaran

Isi pengeluaran harian seperti transport, penginapan, dan konsumsi.

### Tujuan
Memudahkan pengguna mencatat pengeluaran harian lapangan seperti transport, penginapan, dan konsumsi dengan cepat.
### Selesai bila
- Form pengeluaran menerima jumlah, kategori, tanggal (otomatis hari ini), dan keterangan singkat.
- Setelah disimpan, pengeluaran muncul di daftar transaksi dan mengurangi saldo proyek aktif.
- Pengguna bisa mencatat pengeluaran tanpa harus mengisi keterangan (opsional).

## Sub-fitur: Catat Pemasukan

Catat dana yang diterima untuk keperluan proyek.

### Tujuan
Mencatat dana yang diterima untuk keperluan proyek agar saldo proyek bertambah dengan benar.
### Selesai bila
- Form pemasukan menerima jumlah, sumber/kategori, tanggal, dan keterangan opsional.
- Setelah disimpan, pemasukan muncul di daftar transaksi dan menambah saldo proyek aktif.
- Jenis pemasukan mudah dibedakan dari pengeluaran (mis. warna atau tanda).

## Sub-fitur: Kategori & Tanggal

Tandai jenis pengeluaran dan tanggalnya supaya mudah ditelusuri.

### Tujuan
Menandai jenis transaksi dan tanggalnya supaya pengguna mudah menelusuri dan mengelompokkan catatan.
### Selesai bila
- Saat mencatat, pengguna dapat memilih kategori dari daftar (mis. transport, konsumsi, penginapan).
- Tanggal transaksi otomatis terisi hari ini, tetapi bisa diubah jika mencatat untuk hari lain.
- Kategori dan tanggal tampil di daftar transaksi untuk memudahkan pencarian.

## Sub-fitur: Ubah & Hapus Catatan

Perbaiki atau batalkan catatan yang salah masuk.

### Tujuan
Memungkinkan pengguna memperbaiki atau membatalkan catatan yang salah masuk agar data tetap akurat.
### Selesai bila
- Pengguna dapat membuka catatan yang sudah ada dan mengubah jumlah, kategori, tanggal, atau keterangan.
- Pengguna dapat menghapus catatan dengan konfirmasi agar tidak terhapus tidak sengaja.
- Setelah diubah atau dihapus, saldo proyek dan daftar transaksi langsung diperbarui.

## Task

### 1. Bangun halaman transaksi dengan data tiruan

### 2. Buat form catat pengeluaran tiruan

### 3. Buat form catat pemasukan tiruan

### 4. Buat komponen pilih kategori dan tanggal

### 5. Tampilkan daftar transaksi dengan penanda jenis

### 6. Buat alur ubah dan hapus dengan konfirmasi

### 7. Buat skema tabel transaksi dan migrasi

### 8. Buat endpoint tambah pengeluaran dan pemasukan

### 9. Buat endpoint daftar transaksi dan saldo

### 10. Buat kalkulasi saldo otomatis dari transaksi

### 11. Buat endpoint ubah transaksi

### 12. Buat endpoint hapus transaksi
