# Masuk Akun

Mengamankan data keuangan pribadi di balik akun pengguna.

## Spesifikasi

### Tujuan
Membuat akun pribadi agar hanya pemiliknya yang bisa membuka dan melihat catatan keuangan lapangan, sehingga data uang dan foto struk tetap rahasia.

### Selesai bila
- Pengguna baru bisa membuat akun dengan email atau nomor HP, lalu langsung bisa masuk ke aplikasi.
- Pengguna bisa masuk dan keluar dari aplikasi di HP-nya dengan aman.
- Saat lupa sandi, pengguna bisa memulihkan akses ke akunnya tanpa kehilangan data keuangan.
- Data proyek, transaksi, dan foto struk hanya terlihat oleh pemilik akun yang sedang masuk.
- Pengguna yang belum masuk diarahkan ke halaman masuk sebelum bisa melihat dashboard saldo.

## Sub-fitur: Daftar Akun

Buat akun baru dengan email atau nomor HP.

### Tujuan
Memungkinkan pengguna baru membuat akun sendiri supaya catatan keuangannya tersimpan dan terlindungi sejak awal.

### Selesai bila
- Tersedia formulir pendaftaran yang bisa diisi dengan email atau nomor HP, nama, dan kata sandi.
- Setelah mendaftar berhasil, pengguna langsung masuk ke aplikasi dan diarahkan ke Dashboard Saldo.
- Bila email/nomor HP sudah pernah dipakai atau data belum lengkap, muncul pesan kesalahan berbahasa Indonesia yang jelas.
- Kata sandi ditampilkan tersembunyi dan ada pilihan untuk melihatnya saat diisi.

## Sub-fitur: Masuk & Keluar

Masuk ke aplikasi dan keluar dengan aman dari perangkat.

### Tujuan
Memberi jalan bagi pengguna untuk masuk kembali ke akunnya dan keluar dengan aman, terutama saat berganti perangkat atau meminjamkan HP.

### Selesai bila
- Pengguna bisa masuk memakai email atau nomor HP beserta kata sandi yang benar.
- Bila data masuk salah, muncul pesan yang menjelaskan tanpa membocorkan mana yang salah.
- Ada tombol Keluar yang mengakhiri sesi dan mengembalikan pengguna ke halaman masuk.
- Setelah keluar, membuka aplikasi lagi tidak langsung memperlihatkan data keuangan tanpa memasukkan akun.

## Sub-fitur: Atur Ulang Sandi

Pulihkan akses saat lupa kata sandi.

### Tujuan
Menolong pengguna yang lupa kata sandinya agar bisa kembali mengakses akun dan data keuangannya.

### Selesai bila
- Ada tautan "Lupa kata sandi?" di halaman masuk yang membuka proses pemulihan.
- Pengguna bisa meminta tautan/kode pemulihan ke email atau nomor HP terdaftar.
- Pengguna bisa menetapkan kata sandi baru lalu masuk memakai sandi tersebut.
- Setelah sandi diubah, kata sandi lama tidak bisa dipakai lagi dan data keuangan tetap utuh.

## Task

### 1. Bangun halaman masuk dengan data tiruan

### 2. Buat form pendaftaran akun dengan mock

### 3. Buat form masuk dan aksi keluar dengan mock

### 4. Buat alur lupa dan reset sandi dengan mock

### 5. Pasang guard rute dan state sesi tiruan

### 6. Buat skema tabel pengguna dan migrasi

### 7. Buat endpoint registrasi akun email atau HP

### 8. Buat endpoint login logout dan sesi aman

### 9. Buat endpoint lupa dan reset sandi

### 10. Buat middleware proteksi data per pemilik akun
