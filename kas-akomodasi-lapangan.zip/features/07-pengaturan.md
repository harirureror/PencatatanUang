# Pengaturan

Mengatur cara aplikasi bekerja sesuai kebiasaan pemegang operasional lapangan.

## Spesifikasi

### Tujuan
Memberi pemegang operasional lapangan tempat untuk menyesuaikan cara aplikasi bekerja—kategori, format uang, dan profil—agar sesuai kebiasaannya sehari-hari.

### Selesai bila
- Ada satu halaman Pengaturan yang dapat dibuka dari menu utama, berisi tiga bagian: Kategori, Format Uang, dan Profil Pengguna.
- Setiap perubahan yang disimpan langsung berlaku di seluruh aplikasi tanpa perlu menutup atau membuka ulang aplikasi.
- Muncul pesan konfirmasi singkat setiap kali perubahan berhasil disimpan.
- Selama pengguna belum mengubah apa pun, aplikasi memakai nilai bawaan (Rupiah dengan format angka umum dan kategori standar lapangan).
- Tersedia cara kembali ke pengaturan bawaan bila pengguna ingin mengembalikan semuanya seperti semula.

## Sub-fitur: Atur Kategori

Sesuaikan jenis pengeluaran yang biasa dipakai di lapangan.

### Tujuan
Memungkinkan pengguna menyesuaikan daftar kategori pemasukan dan pengeluaran agar cocok dengan kebutuhan nyata di lapangan.

### Selesai bila
- Pengguna dapat melihat daftar kategori, terpisah antara pemasukan dan pengeluaran, serta membedakan mana kategori bawaan dan mana kategori buatannya sendiri.
- Pengguna dapat menambah kategori baru dengan nama pilihannya sendiri, dan kategori tersebut langsung tersedia saat mencatat transaksi.
- Pengguna dapat mengganti nama atau menghapus kategori buatannya sendiri, sementara kategori bawaan hanya bisa dilihat tanpa bisa dihapus.

## Sub-fitur: Format Uang

Pilih mata uang dan cara penulisan angka yang dipakai.

### Tujuan
Membuat tampilan nominal uang mengikuti kebiasaan pengguna, baik dari sisi mata uang maupun cara penulisan angkanya.

### Selesai bila
- Pengguna dapat memilih mata uang dan cara penulisan angka (misalnya 1.000.000 atau 1,000,000).
- Contoh tampilan langsung diperbarui saat pilihan diubah, sehingga pengguna bisa melihat hasilnya sebelum menyimpan.
- Setelah disimpan, semua nominal di aplikasi—dashboard, daftar transaksi, dan rekap—mengikuti format yang dipilih.

## Sub-fitur: Profil Pengguna

Perbarui nama dan informasi kontak pengguna.

### Tujuan
Memberi pengguna kendali untuk memperbarui nama dan informasi kontaknya agar data akun tetap akurat.

### Selesai bila
- Pengguna dapat melihat dan mengubah nama tampilan, email, dan nomor HP-nya.
- Perubahan yang disimpan langsung tampil di aplikasi, misalnya nama baru muncul pada sapaan di halaman utama.
- Jika email atau nomor HP yang dimasukkan tidak valid atau sudah dipakai akun lain, muncul pesan kesalahan yang jelas dan perubahan tidak tersimpan.

## Task

### 1. Bangun halaman Pengaturan tiga bagian

### 2. Tampilkan daftar kategori pemasukan pengeluaran

### 3. Buat form tambah ubah hapus kategori

### 4. Buat pemilih mata uang dengan pratinjau

### 5. Buat form profil dengan pesan kesalahan

### 6. Terapkan pengaturan global dan reset bawaan

### 7. Buat skema tabel pengaturan dan kategori

### 8. Buat endpoint CRUD kategori

### 9. Buat endpoint simpan format uang

### 10. Buat endpoint update profil validasi

### 11. Buat endpoint reset pengaturan bawaan
