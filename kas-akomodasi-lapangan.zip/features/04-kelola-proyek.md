# Kelola Proyek

Memisahkan pencatatan uang untuk tiap proyek pemetaan atau site visit.

## Spesifikasi

### Tujuan
Memisahkan pencatatan uang untuk tiap proyek pemetaan atau site visit, sehingga dana antar proyek tidak tercampur dan pengguna selalu tahu proyek mana yang sedang dicatat.

### Selesai bila
- Pengguna dapat melihat semua proyeknya (yang sedang berjalan maupun yang sudah selesai) beserta saldo masing-masing dalam satu daftar.
- Pengguna dapat membuat proyek baru dengan nama, dana yang disiapkan, dan rentang tanggal, lalu langsung memakainya.
- Pengguna dapat berpindah proyek aktif tanpa keluar aplikasi, dan transaksi baru otomatis masuk ke proyek yang sedang aktif.
- Pengguna dapat membuka satu proyek untuk melihat rincian dana, daftar transaksi, dan saldo proyek tersebut.
- Setiap proyek hanya menampilkan data milik pemiliknya, dan saldo tiap proyek dihitung terpisah dari proyek lain.

## Sub-fitur: Daftar Proyek

Lihat semua proyek yang pernah dan sedang dikerjakan.

### Tujuan
Menampilkan semua proyek yang pernah dan sedang dikerjakan agar pengguna bisa memilih proyek mana yang ingin dilihat atau dicatat.

### Selesai bila
- Daftar menampilkan setiap proyek dengan nama, status (aktif/selesai), dan saldo saat ini dalam format Rupiah.
- Proyek yang sedang aktif ditandai jelas sehingga mudah dikenali di antara proyek lain.
- Bila belum ada proyek sama sekali, muncul pesan ajakan untuk membuat proyek pertama.

## Sub-fitur: Tambah Proyek

Buat proyek baru beserta dana yang disiapkan untuknya.

### Tujuan
Membuat proyek baru beserta dana yang disiapkan, sebagai wadah pencatatan uang selama pekerjaan lapangan berlangsung.

### Selesai bila
- Pengguna dapat mengisi nama proyek, dana yang disiapkan, dan rentang tanggal (tanggal selesai boleh dikosongkan).
- Proyek yang baru disimpan langsung muncul di daftar proyek dan bisa dipilih sebagai proyek aktif.
- Bila nama atau dana belum diisi dengan benar, muncul pesan yang menjelaskan bagian mana yang perlu diperbaiki.

## Sub-fitur: Pindah Proyek Aktif

Ganti proyek yang sedang dicatat tanpa keluar aplikasi.

### Tujuan
Mengganti proyek yang sedang dicatat tanpa keluar aplikasi, supaya pencatatan tidak salah masuk ke proyek lain.

### Selesai bila
- Pengguna dapat memilih proyek lain dari daftar dan menjadikannya proyek aktif.
- Proyek yang sedang aktif terlihat jelas (misalnya namanya tampil di Dashboard dan pada formulir catat transaksi).
- Setelah berpindah, transaksi baru yang dicatat langsung tercatat pada proyek yang baru dipilih, dan saldo proyek sebelumnya tidak berubah.

## Sub-fitur: Detail Proyek

Buka rincian dana, transaksi, dan saldo satu proyek tertentu.

### Tujuan
Membuka rincian satu proyek agar pengguna dapat memeriksa dana, transaksi, dan saldo proyek tersebut secara utuh.

### Selesai bila
- Halaman detail menampilkan nama proyek, dana yang disiapkan, total pemasukan, total pengeluaran, dan saldo akhir dalam format Rupiah.
- Daftar transaksi proyek tersebut ditampilkan berurutan berdasarkan tanggal, lengkap dengan kategori dan nominalnya.
- Dari halaman ini pengguna dapat menjadikan proyek tersebut sebagai proyek aktif.

## Task

### 1. Bangun halaman daftar proyek dengan data tiruan

### 2. Buat kartu proyek dengan status dan saldo

### 3. Tandai proyek aktif dan empty state daftar

### 4. Buat form tambah proyek dengan validasi

### 5. Buat halaman detail proyek dengan data tiruan

### 6. Tampilkan proyek aktif di Dashboard dan form transaksi

### 7. Tambah aksi jadikan proyek aktif di UI

### 8. Buat skema tabel proyek dan migrasi

### 9. Relasikan proyek aktif dan transaksi ke proyek

### 10. Buat endpoint daftar dan tambah proyek

### 11. Buat endpoint detail proyek dengan agregasi saldo

### 12. Buat endpoint ganti proyek aktif

### 13. Filter kepemilikan user pada endpoint proyek
