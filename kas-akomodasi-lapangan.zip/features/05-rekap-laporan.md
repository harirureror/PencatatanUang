# Rekap Laporan

Menyusun rangkuman harian dan mingguan yang rapi untuk dilihat atau dibagikan.

## Spesifikasi

### Tujuan
Memberi pengguna cara cepat melihat dan membagikan rangkuman pemakaian uang lapangan (harian/mingguan) tanpa menyusun ulang catatan manual.
### Selesai bila
- Pengguna dapat membuka halaman Rekap Laporan dari menu utama dan langsung melihat ringkasan dalam Bahasa Indonesia dengan format Rupiah.
- Tersedia pilihan periode harian dan mingguan, serta pilihan proyek, yang hasilnya langsung berubah saat diganti.
- Ringkasan menampilkan total pemasukan, total pengeluaran, dan selisih/saldo untuk periode yang dipilih.
- Daftar transaksi penyusun rekap ditampilkan rapi (tanggal, kategori, keterangan, nominal) dan bisa digulir.
- Pengguna dapat membagikan atau mengekspor rekap yang sedang dilihat ke pihak lain.
- Jika belum ada data pada periode terpilih, muncul pesan jelas bahwa belum ada transaksi (bukan halaman kosong).

## Sub-fitur: Rekap Harian

Lihat pemasukan dan pengeluaran dalam satu hari kerja lapangan.

### Tujuan
Menampilkan seluruh pemasukan dan pengeluaran yang terjadi pada satu hari kerja agar pengguna tahu pemakaian uang hari itu.
### Selesai bila
- Pengguna memilih tanggal (default hari ini) dan melihat total pemasukan, total pengeluaran, serta selisihnya untuk hari itu.
- Daftar transaksi hari tersebut tampil urut dengan tanggal, kategori, keterangan, dan nominal berformat Rupiah.
- Bila tidak ada transaksi di hari itu, muncul pesan bahwa belum ada catatan untuk tanggal tersebut.

## Sub-fitur: Rekap Mingguan

Lihat gambaran pemakaian dana selama satu minggu.

### Tujuan
Menampilkan gambaran pemakaian dana selama satu minggu agar pengguna bisa memantau pola pengeluaran.
### Selesai bila
- Pengguna dapat memilih minggu tertentu (default minggu berjalan) dan melihat total pemasukan, total pengeluaran, serta selisihnya untuk minggu itu.
- Rincian transaksi minggu tersebut ditampilkan per hari sehingga mudah ditelusuri.
- Nominal ditampilkan dalam format Rupiah dan tanggal mengikuti format Indonesia.

## Sub-fitur: Filter Periode & Proyek

Pilih rentang waktu dan proyek mana yang ingin dilihat.

### Tujuan
Memungkinkan pengguna menentukan rentang waktu dan proyek mana yang ingin dilihat pada rekap.
### Selesai bila
- Tersedia pilihan periode (harian/mingguan) dan pilihan proyek yang bisa diganti tanpa keluar dari halaman rekap.
- Rekap yang tampil langsung menyesuaikan pilihan periode dan proyek tersebut.
- Pilihan yang sedang aktif terlihat jelas sehingga pengguna tahu rekap mana yang sedang dilihat.

## Sub-fitur: Bagikan Rekap

Kirim atau ekspor rangkuman ke atasan atau tim.

### Tujuan
Mengirim atau mengekspor rangkuman rekap ke atasan atau tim agar tidak perlu menyusun laporan ulang.
### Selesai bila
- Pengguna dapat membagikan rekap yang sedang dilihat melalui aplikasi berbagi di HP (mis. pesan/email).
- Hasil ekspor/bagikan memuat periode, proyek, total pemasukan, total pengeluaran, dan rincian transaksi yang mudah dibaca.
- Setelah dibagikan, pengguna mendapat konfirmasi bahwa rekap berhasil dikirim atau diekspor.

## Task

### 1. Bangun halaman utama Rekap Laporan dengan data tiruan

### 2. Buat tampilan rekap harian dengan pemilih tanggal

### 3. Buat tampilan rekap mingguan dengan rincian per hari

### 4. Buat kontrol filter periode dan proyek

### 5. Buat aksi bagikan dan ekspor rekap

### 6. Tampilkan empty state saat rekap kosong

### 7. Buat layanan agregasi total pemasukan pengeluaran dan saldo

### 8. Buat endpoint ringkasan rekap harian

### 9. Buat endpoint ringkasan rekap mingguan per hari

### 10. Buat endpoint daftar proyek untuk filter

### 11. Buat endpoint ekspor rekap terformat
