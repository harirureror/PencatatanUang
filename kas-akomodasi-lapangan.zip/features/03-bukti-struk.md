# Bukti Struk

Menyimpan foto struk atau bukti bayar sebagai pendukung setiap catatan transaksi.

## Spesifikasi

### Tujuan
Menyimpan foto struk atau bukti bayar sebagai pendukung tiap catatan transaksi, supaya catatan uang lapangan bisa dipercaya dan tidak kehilangan nota.
### Selesai bila
- Setiap transaksi bisa memiliki satu atau lebih foto bukti yang menempel pada catatan tersebut.
- Pengguna bisa menambahkan bukti langsung dari kamera HP atau dari galeri saat mencatat transaksi.
- Foto bukti bisa dibuka kembali dari daftar maupun detail transaksi kapan saja.
- Transaksi yang belum ada buktinya bisa ditandai "tanpa struk" agar terlihat mana yang belum lengkap.
- Foto bukti hanya bisa dilihat oleh pemilik akun.

## Sub-fitur: Foto Struk

Ambil foto struk langsung dari kamera HP saat transaksi terjadi.

### Tujuan
Mengambil foto struk langsung dari kamera HP saat transaksi dicatat, supaya bukti tersimpan seketika tanpa langkah tambahan.
### Selesai bila
- Ada tombol untuk membuka kamera HP saat menambah atau mengubah transaksi.
- Hasil jepretan langsung menempel sebagai lampiran transaksi setelah disimpan.
- Pengguna bisa membatalkan atau mengulang pengambilan foto sebelum menyimpan.

## Sub-fitur: Unggah dari Galeri

Tambahkan bukti bayar dari foto yang sudah tersimpan di HP.

### Tujuan
Menambahkan foto bukti yang sudah tersimpan di HP sebagai lampiran transaksi, untuk struk yang baru difoto belakangan.
### Selesai bila
- Ada pilihan mengambil bukti dari galeri atau folder foto HP.
- Foto terpilih tampil sebagai lampiran transaksi setelah disimpan.
- Pengguna bisa memilih lebih dari satu foto untuk satu transaksi.

## Sub-fitur: Lihat Lampiran

Buka kembali foto bukti dari daftar transaksi kapan saja.

### Tujuan
Membuka kembali foto bukti dari daftar transaksi agar mudah dicek ulang saat merekap atau saat ditanya atasan.
### Selesai bila
- Daftar transaksi menampilkan penanda bila transaksi punya lampiran.
- Menekan lampiran membuka foto bukti dalam tampilan layar penuh.
- Bila satu transaksi punya beberapa foto, pengguna bisa berpindah antar foto.

## Sub-fitur: Tandai Tanpa Struk

Beri tanda pada transaksi yang buktinya belum lengkap.

### Tujuan
Menandai transaksi yang buktinya belum ada, agar pengguna tahu catatan mana yang masih perlu dilengkapi.
### Selesai bila
- Saat menyimpan transaksi, pengguna bisa memilih status "tanpa struk".
- Transaksi tanpa struk tampil berbeda dan jelas di daftar transaksi.
- Tanda "tanpa struk" hilang otomatis begitu foto bukti ditambahkan.

## Task

### 1. Bangun halaman lampiran struk dengan data tiruan

### 2. Buat komponen kamera ambil foto struk

### 3. Buat pemilih foto galeri multi-pilih

### 4. Hubungkan pratinjau lampiran ke form transaksi

### 5. Buat penampil foto layar penuh bernavigasi

### 6. Tampilkan penanda lampiran di daftar transaksi

### 7. Buat kontrol status tanpa struk transaksi

### 8. Buat skema dan migrasi tabel lampiran transaksi

### 9. Buat endpoint unggah bukti struk

### 10. Buat endpoint ambil lampiran transaksi

### 11. Tambah kolom status tanpa struk dan auto-hapus

### 12. Batasi akses lampiran hanya pemilik akun
