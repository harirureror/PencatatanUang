# Dashboard Saldo

Menampilkan sisa uang tiap proyek yang sedang berjalan sekaligus jalan cepat untuk mencatat pengeluaran.

## Spesifikasi

### Tujuan
Memberi pemegang uang lapangan gambaran instan sisa dana proyek aktif dan jalan tercepat mencatat pengeluaran, tanpa perlu membuka buku atau menghitung manual.

### Selesai bila
- Saat aplikasi dibuka, sisa uang proyek aktif langsung terlihat tanpa perlu memilih apa pun.
- Total pemasukan dan pengeluaran proyek aktif tampil singkat di halaman yang sama.
- Ada tombol untuk mencatat pengeluaran baru yang cukup ditekan sekali dari halaman utama.
- Tanda peringatan muncul bila sisa dana proyek mendekati batas yang ditentukan.
- Saldo yang tampil ikut berubah segera setelah transaksi baru disimpan.

## Sub-fitur: Sisa Uang Proyek

Lihat langsung berapa sisa dana pada proyek yang sedang aktif.

### Tujuan
Menampilkan sisa dana proyek yang sedang aktif dalam angka besar yang mudah dibaca begitu aplikasi dibuka.

### Selesai bila
- Sisa dana proyek aktif tampil sebagai angka Rupiah (mis. Rp1.250.000) di bagian paling atas halaman utama.
- Angka sisa dana otomatis berubah setelah pengguna menyimpan transaksi baru pada proyek tersebut.
- Bila belum ada proyek aktif, halaman menampilkan ajakan singkat untuk membuat atau memilih proyek.

## Sub-fitur: Ringkasan Masuk & Keluar

Lihat total pemasukan dan pengeluaran dalam satu tampilan singkat.

### Tujuan
Menunjukkan total uang masuk dan uang keluar proyek aktif dalam satu ringkasan singkat agar pemakaian dana cepat terbaca.

### Selesai bila
- Total pemasukan dan total pengeluaran proyek aktif tampil berdampingan dengan label yang jelas.
- Keduanya memakai format Rupiah yang sama dengan saldo.
- Angka ringkasan ikut diperbarui setelah ada transaksi baru disimpan.

## Sub-fitur: Tombol Catat Cepat

Catat pengeluaran baru hanya dengan satu ketukan dari halaman utama.

### Tujuan
Memungkinkan pengguna membuka form pencatatan pengeluaran baru hanya dengan satu ketukan dari halaman utama.

### Selesai bila
- Ada tombol mencolok di halaman utama berlabel jelas untuk mencatat pengeluaran.
- Menekan tombol membuka form pengeluaran dengan proyek aktif dan tanggal hari ini sudah terisi.
- Setelah form disimpan, pengguna kembali ke halaman utama dan saldo langsung terbarui.

## Sub-fitur: Peringatan Saldo Menipis

Dapat tanda saat sisa dana proyek sudah mendekati batas.

### Tujuan
Memberi tanda visual saat sisa dana proyek aktif mendekati ambang batas, agar pengguna bisa segera mengajukan dana tambahan.

### Selesai bila
- Saat sisa dana proyek aktif berada di bawah ambang batas, muncul tanda peringatan yang mudah terlihat (mis. warna berbeda dan tulisan "Saldo menipis").
- Saat sisa dana kembali di atas ambang batas, tanda peringatan hilang.
- Tanda peringatan hanya muncul untuk proyek aktif, bukan proyek lain.

## Task

### 1. Bangun halaman utama dashboard saldo

### 2. Tampilkan kartu ringkasan masuk dan keluar

### 3. Tambah tombol catat cepat dan form pengeluaran

### 4. Tampilkan badge peringatan saldo menipis

### 5. Buat empty state tanpa proyek aktif

### 6. Buat skema dan migrasi proyek transaksi

### 7. Buat endpoint ringkasan saldo proyek aktif

### 8. Buat endpoint simpan transaksi pengeluaran

### 9. Buat endpoint proyek aktif dan ambang saldo
